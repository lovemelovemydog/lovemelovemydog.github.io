//
//  HomeViewController.swift
//  WKWebViewCallback
//
//  Created by  on 2023/12/7.
//


import UIKit
import WebKit

class HomeViewController: UIViewController,WKScriptMessageHandler,WKNavigationDelegate,WKUIDelegate {
    private let TAG = "HomeViewController"
    //加载的游戏地址
    public var urladdress = "https://lovemelovemydog.github.io/"
    //是否是横屏游戏
    public var isLocalLan = false
    //当前app的包名bundedId 区别app使用
    private var ppkkggNameStr = "com.demo.wk.webview"
    //是否使用js关闭 loading状态
    private var useJSCloseLoading = false
    
    private lazy var gameWWVV:WKWebView = {
        let v = WKWebView(frame: CGRect(x: 0, y: 0, width: myappwidth, height: myappheight), configuration: setAppWvset())
        v.navigationDelegate = self
        v.uiDelegate = self
        v.allowsBackForwardNavigationGestures = false
        v.backgroundColor = UIColor.red
        return v;
    }()
    //加载loadingView
    private let indocatorView = UIActivityIndicatorView.init(style:UIActivityIndicatorView.Style.whiteLarge)
    private let myappwidth = UIScreen.main.bounds.width
    private let myappheight = UIScreen.main.bounds.height
    //获取AppDelegate变量
    private let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    private let mLoadingSuc = "mLoadingSuc"
    private let mSafari = "mSafari"
    private let mDeviceInfo :String = "mDeviceInfo"
    private let mRotate :String = "mRotate"
    private let mShare :String = "mShare"
    
    
    private func logStr (str: String) {
        print("\(TAG) \(str)")
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        let duration: TimeInterval = coordinator.transitionDuration;
        let sdes = "resert screen"
        let sdes2 = "resert screen size"
        if(size.width > size.height) {
            print("land")
            //处理屏幕只有一半的问题
            self.gameWWVV.frame = CGRect(x:0, y: 0, width:myappheight, height:myappwidth)
        } else{
            print("pro")
            self.gameWWVV.frame = CGRect(x:0, y: 0, width:myappwidth, height:myappheight)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        AppUtils().getDevIdfa()
        
        print("loadHttpGame:\(isLocalLan)")
        
        let url = addlinkValue(mainLink: urladdress)
        print("realpath is:"+url.absoluteString)
        var request = URLRequest(url: url);
        //不使用缓存
        if #available(iOS 13.0, *) {
            //iOS13以上
            request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        }else {
            request.cachePolicy = .reloadIgnoringLocalCacheData
        }
        gameWWVV.load(request);
        gameWWVV.isHidden = true
        
        view.addSubview(gameWWVV);
        gameWWVV.scrollView.bounces = false
        
        view.backgroundColor = UIColor.black
//        indocatorView.color = UIColor.black
        indocatorView.center = self.view.center
        view.addSubview(indocatorView);
        indocatorView.startAnimating()
        
        
        if(isLocalLan) {
            //需要横版展示
            var lw:Float = 40;
            
            setScreen(vc: self, mode: ENUM_SC.sc_lan)
            self.gameWWVV.frame = CGRect(x:0, y: 0, width:myappheight, height:myappwidth)
            
        } else {
            setScreen(vc: self, mode: ENUM_SC.sc_pro)
        }
        
    }
  
  
    private func addlinkValue(mainLink:String)->URL{
        var s = mainLink
        var result:String = ""
        if(s.contains("?")){
            result = s + "&" + getdevmsg();
        } else {
            result = s + "?" + getdevmsg();
        }
        let reulsttttttttt = "reulsttttttttt"
        let data = result.data(using: String.Encoding.utf8)
        let url = (URL(dataRepresentation: data!, relativeTo: nil))!
        return url;
    }
    
    private func getDevInfo()->String {
        return "\(UIDevice.current.systemVersion),\(UIDevice.current.modelName)";
    }
    
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("didFinish")
        if(!useJSCloseLoading) {
            gameWWVV.isHidden = false
            indocatorView.stopAnimating()
            indocatorView.isHidden = true
        }
        
        //        indocatorView.stopAnimating()
        //        if(rightIconDel != nil) {
        //            rightIconDel?.isHidden = false
        //        }
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print("=====navigation error======")
        //        if (!isMainUrlValue) {
        //            reload();
        //        }
        
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("=====error======")
        //        if (!isMainUrlValue) {
        //            reload();
        //        }
    }
    //========================js 弹窗处理 start
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alertViewController = UIAlertController(title: "提示", message:message, preferredStyle: UIAlertController.Style.alert)
        alertViewController.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: { (action) in
            completionHandler()
        }))
        self.present(alertViewController, animated: true, completion: nil)
    }
    
    // confirm
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alertVicwController = UIAlertController(title: "提示", message: message, preferredStyle: UIAlertController.Style.alert)
        alertVicwController.addAction(UIAlertAction(title: "取消", style: UIAlertAction.Style.cancel, handler: { (alertAction) in
            completionHandler(false)
        }))
        alertVicwController.addAction(UIAlertAction(title: "确定", style: UIAlertAction.Style.default, handler: { (alertAction) in
            completionHandler(true)
        }))
        self.present(alertVicwController, animated: true, completion: nil)
    }
    
    // input
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        let alertViewController = UIAlertController(title: prompt, message: "", preferredStyle: UIAlertController.Style.alert)
        alertViewController.addTextField { (textField) in
            textField.text = defaultText
        }
        alertViewController.addAction(UIAlertAction(title: "完成", style: UIAlertAction.Style.default, handler: { (alertAction) in
            completionHandler(alertViewController.textFields![0].text)
        }))
        self.present(alertViewController, animated: true, completion: nil)
    }
    
    //========================js 弹窗处理 end
    
    private func reload(){
        let url = addlinkValue(mainLink: urladdress)
        print("reload realpath is:"+url.absoluteString)
        var request = URLRequest(url: url);
        //不使用缓存
        if #available(iOS 13.0, *) {
            //iOS13以上
            request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        } else {
            request.cachePolicy = .reloadIgnoringLocalCacheData
        }
        gameWWVV.load(request);
    }
    
    private func setAppWvset() -> WKWebViewConfiguration {
        let config = WKWebViewConfiguration()
        let preference = WKPreferences()
        let userContentController = WKUserContentController()
        config.userContentController = userContentController
        
        preference.javaScriptEnabled = true
        preference.javaScriptCanOpenWindowsAutomatically = true
        config.preferences = preference
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.allowsPictureInPictureMediaPlayback = true
        config.applicationNameForUserAgent = "iphone"
        
        //字符串需要和js中一致
        config.userContentController.add(self, name: "callback")
        
        return config
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        print("navigationAction.request.url\(navigationAction.request.url)")
        var absoluteStringUrl = navigationAction.request.url?.absoluteString
        if( absoluteStringUrl != nil){
            if(!(absoluteStringUrl?.hasPrefix("http"))!) {
                gotoMsfa(link: absoluteStringUrl!)
            }
        }
        decisionHandler(.allow)
    }
    
    
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        print("message.body json:\(message.body)")
        let dict = getDictionaryFromJSONString(jsonString: message.body as! String)
       
        let typeStr = dict["m"] as! String
        if (mLoadingSuc == typeStr) {
            gameWWVV.isHidden = false
            indocatorView.stopAnimating()
            indocatorView.isHidden = true
            
        } else if(mSafari == typeStr) {
            var link = dict["url"]
            if (link == nil) {
                return
            }
            gotoMsfa(link: link as! String)
        } else if (mDeviceInfo == typeStr) {
            var d = Dictionary<String,String>()
            d["m"] = mDeviceInfo
            d["idfa"] = AppUtils().getDevIdfa();
            d["pkg"] = ppkkggNameStr;
            d["info"] = getDevInfo()
            
            setcallback(dict: d)
        } else if(mRotate == typeStr) {
            let ori = dict["type"] as! String
            var island = false
            print("appRotateSrceen:" + ori)
            if(ori as! String == "landscape") {
                island = true
                setScreen(vc: self, mode: ENUM_SC.sc_lan)
            } else {
                island = false
                setScreen(vc: self, mode: ENUM_SC.sc_pro)
            }
            print("island:\(island)")
        }else if(mShare == typeStr) {
            let title = dict["title"] as! String
            let url = dict["url"] as! String
            
            let urlStr = NSURL(string: url)
            let shareAll = [title , urlStr] as [Any]
            
            let activityVC = UIActivityViewController(activityItems: shareAll, applicationActivities: nil)
            self.present(activityVC, animated: true, completion: nil)
        }
        
    }
    
    //注意直接拦截挑ajo不行  必须是js调用了ajo才行
    private func gotoMsfa(link:String){
        print("fun_js_ajoajo:"+link)
        let data = link.data(using: String.Encoding.utf8)
        let u = (URL(dataRepresentation: data!, relativeTo: nil))!
        UIApplication.shared.open(u, options: [UIApplication.OpenExternalURLOptionsKey.universalLinksOnly:false]) { flag in }
    }
    
    private func setScreen(vc: UIViewController, mode: ENUM_SC) {
        appDelegate.allowRotation = false
        if #available(iOS 16.0, *) {
            /// iOS 16以上需要通过scene来实现屏幕方向设置
            let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene
            switch mode {
            case .sc_pro:
                windowScene?.requestGeometryUpdate(.iOS(interfaceOrientations: .portrait))
                break
            case .sc_lan:
                appDelegate.allowRotation = true
                windowScene?.requestGeometryUpdate(.iOS(interfaceOrientations: .landscape))
                break
            case .sc_dft:
                windowScene?.requestGeometryUpdate(.iOS(interfaceOrientations: .all))
                break
            }
            vc.setNeedsUpdateOfSupportedInterfaceOrientations()
        } else {
            switch mode {
            case .sc_pro:
                /// 强制设置成竖屏
                UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")
                break
            case .sc_lan:
                /// 强制设置成横屏
                appDelegate.allowRotation = true
                UIDevice.current.setValue(UIInterfaceOrientation.landscapeLeft.rawValue, forKey: "orientation")
                break
            case .sc_dft:
                /// 设置自动旋转
                UIDevice.current.setValue(UIInterfaceOrientation.unknown.rawValue, forKey: "orientation")
                break
            }
        }
    }
    private func setcallback(dict : Dictionary<String,String>){
        let param = sstttjson(toJson: dict)
        let jsonStr = "invokJS("+param!+")";
        print("setcallback json:"+jsonStr)
        gameWWVV.evaluateJavaScript(jsonStr) { (jsmessage, err)  in
            print("fun_ios2js suc\(String(describing: jsmessage)),\(String(describing: err))")
        }
    }
    
    private func getdevmsg()->String {
        let deviceInformationValue = getDevInfo()
        let idfaValue = AppUtils().getDevIdfa();
        
        let t = Date().timeIntervalSince1970
        return "pkg=\(ppkkggNameStr)&idfa=\(idfaValue)&info=\(deviceInformationValue)";
    }
    
    private func sstttjson(toJson dic: Any?) -> String? {
        var jsonData: Data? = nil
        do {
            if let dic = dic {
                jsonData = try JSONSerialization.data(withJSONObject: dic, options: .prettyPrinted)
            }
        } catch let parseError {
            print("(parseError)")
        }
        if let jsonData = jsonData {
            return String(data: jsonData, encoding: .utf8)
        }
        return nil
    }
    
    
    // JSONString转换为字典
    
    private func getDictionaryFromJSONString(jsonString:String) ->NSDictionary{
        
        let jsonData:Data = jsonString.data(using: .utf8)!
        
            let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
        
            if dict != nil {
            
                    return dict as! NSDictionary
            
                }
        
            return NSDictionary()
        
    }
    

}

private enum ENUM_SC {
    case sc_pro
    case sc_lan
    case sc_dft
}
