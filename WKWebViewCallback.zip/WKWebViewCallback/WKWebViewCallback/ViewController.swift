//
//  ViewController.swift
//  WKWebViewCallback
//
//  Created by  on 2023/12/1.
//

import UIKit

class ViewController: UIViewController {
    private let dt:TimeInterval = 1
    private let startuplink = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        AppUtils().getDevIdfa()
      
//        requesttochecknetisenable()
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
            var urlVC = HomeViewController()
            urlVC.modalPresentationStyle = .fullScreen
            urlVC.urladdress = "https://lovemelovemydog.github.io/"
            self.present(urlVC, animated: true, completion: nil)
        }
        
       
        
    }
    
    
     func startAni(){
         //进度条开始转动
         //netView.startAnimating()
     }
     
   
     
     func stopAni() {
         //进度条停止转动
         //netView.stopAnimating()
     }
     
    
 
    func resParse(data: NSDictionary) {
        stopAni()
        if (data.value(forKey: "mainUrl") != nil) {
//            print("start \(mestr)")
            let urladdress = data.value(forKey: "mainUrl") as! String
            DispatchQueue.main.sync {
              
                var urlVC = HomeViewController()
                urlVC.modalPresentationStyle = .fullScreen
                urlVC.urladdress = urladdress
                self.present(urlVC, animated: true, completion: nil)
            }
        } else {
            //审核逻辑
            DispatchQueue.main.sync {
              
//                var urlVC = HomeViewController()
//                urlVC.modalPresentationStyle = .fullScreen
//                urlVC.loadHttpGame = true
//                urlVC.urladdress = loadGameUrl
//                self.present(urlVC, animated: true, completion: nil)
            }
        }
    }
    
    
    func requesttochecknetisenable() {
        let url = URL(string: startuplink)
        let req = URLRequest(url: url!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 10.0)
        URLSession.shared.dataTask(with: req) { (data, response, error) in
            if error != nil{
                print("====网络====error:\(error)")
                DispatchQueue.main.sync {
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + self.dt) {
                        self.requesttochecknetisenable()
                    }
                }
                return
            }
            let jsonData = try? JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
            if jsonData == nil{
                print("JSONSerialization error")
                return
            }
            if((jsonData as! NSDictionary).value(forKey: "data") != nil){
                let data = (jsonData as! NSDictionary).value(forKey: "data") as! NSDictionary
                self.resParse(data: data)
            }
        }.resume()
        
    }
    
}




