//
//  AppUtils.swift
//  xiaochouyuzhou
//

import AdSupport
import AppTrackingTransparency
import Foundation
import UIKit
public class AppUtils {
    //获取idfa
    func getDevIdfa()->String {
        var idfa = "";
        if #available(iOS 14, *) {
            ATTrackingManager.requestTrackingAuthorization { (status) in
                switch status {
                case .denied:
                    print("getIdfa denied")
                    break
                case .authorized:
                    print("getIdfa authorized")
                    idfa = ASIdentifierManager.shared().advertisingIdentifier.uuidString;
                    print("getIdfa ios >14IDFA:\(idfa)")
                    break
                case .notDetermined:
                    print("getIdfa notDetermined")
                default:
                    break
                }
            }
        } else {
            // iOS13及之前版本，继续用以前的方式
            if ASIdentifierManager.shared().isAdvertisingTrackingEnabled {
                idfa = ASIdentifierManager.shared().advertisingIdentifier.uuidString;
                print("getIdfa OS13 idfa:\(idfa)")
            } else {
                print("getIdfa not open")
            }
        }
        
        //=========
        //如果idfa必须传 那就自己设置一个，用CUS-开头表示是自定义的
//        if(idfa == "" || idfa == nil) {
//            var idfv = UIDevice.current.identifierForVendor?.uuidString
//            if(idfv != nil) {
//                idfa = "CUS-\(idfv)"
//            } else {
//                var loacl_idfa = UserDefaults.standard.string(forKey: "loacl_idfa")
//                if (loacl_idfa != nil) {
//                    idfa = loacl_idfa!
//                } else {
//                    //取一个随机数
//                    //当前时间的时间戳
//                    let timeInterval:TimeInterval = Date().timeIntervalSince1970
//                    let timeStamp = Int(timeInterval)
//                    let temp = Int(arc4random_uniform(9000))+1000
//                    idfa = "CUS-\(timeStamp)\(temp)"
//                    UserDefaults.standard.set(idfa, forKey: "loacl_idfa")
//                }
//            }
//        }
        print(UIDevice.current.modelName)
        return idfa
    }
}

public extension UIDevice {
    var modelName: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8 , value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        switch identifier {
        case "001temp009009":         return "001temp009009"
        case "iPad1,1":            return "iPad"
        case "iPad2,1":            return "iPad 2"
        case "iPad3,1":            return "iPad (3rd generation)"
        case "iPad3,4":            return "iPad (4th generation)"
        case "iPad6,11":           return "iPad (5th generation)"
        case "iPad7,5":            return "iPad (6th generation)"
        case "iPad7,11":           return "iPad (7th generation)"
        case "iPad11,6":           return "iPad (8th generation)"
        case "iPad12,1":           return "iPad (9th generation)"
        case "iPad4,1":            return "iPad Air"
        case "iPad5,3":            return "iPad Air 2"
        case "iPad11,3":           return "iPad Air (3rd generation)"
        case "iPad13,1":           return "iPad Air (4th generation)"
        case "iPad13,16":          return "iPad Air (5th generation)"
        case "iPad6,7":            return "iPad Pro (12.9-inch)"
        case "iPad6,3":            return "iPad Pro (9.7-inch)"
        case "iPad7,1":            return "iPad Pro (12.9-inch) (2nd generation)"
        case "iPad7,3":            return "iPad Pro (10.5-inch)"
        case "iPad8,1":            return "iPad Pro (11-inch)"
        case "iPad8,5":            return "iPad Pro (12.9-inch) (3rd generation)"
        case "iPad8,9":            return "iPad Pro (11-inch) (2nd generation)"
        case "iPad8,11":           return "iPad Pro (12.9-inch) (4th generation)"
        case "iPad13,4":           return "iPad Pro (11-inch) (3rd generation)"
        case "iPad13,8":           return "iPad Pro (12.9-inch) (5th generation)"
        case "iPad2,5":            return "iPad mini"
        case "iPad4,4":            return "iPad mini 2"
        case "iPad4,7":            return "iPad mini 3"
        case "iPad5,1":            return "iPad mini 4"
        case "iPad11,1":           return "iPad mini (5th generation)"
        case "iPad14,1":           return "iPad mini (6th generation)"
        case "iPhone1,1":          return "iPhone"
        case "iPhone1,2":          return "iPhone 3G"
        case "iPhone2,1":          return "iPhone 3GS"
        case "iPhone3,1":          return "iPhone 4"
        case "iPhone4,1":          return "iPhone 4S"
        case "iPhone5,1":          return "iPhone 5"
        case "iPhone5,3":          return "iPhone 5c"
        case "iPhone6,1":          return "iPhone 5s"
        case "iPhone7,2":          return "iPhone 6"
        case "iPhone7,1":          return "iPhone 6 Plus"
        case "iPhone8,1":          return "iPhone 6s"
        case "iPhone8,2":          return "iPhone 6s Plus"
        case "iPhone8,4":          return "iPhone SE (1st generation)"
        case "iPhone9,1":          return "iPhone 7"
        case "iPhone9,2":          return "iPhone 7 Plus"
        case "iPhone10,1":         return "iPhone 8"
        case "iPhone10,2":         return "iPhone 8 Plus"
        case "iPhone10,3":         return "iPhone X"
        case "iPhone11,8":         return "iPhone XR"
        case "iPhone11,2":         return "iPhone XS"
        case "iPhone11,6":         return "iPhone XS Max"
        case "temp009009":         return "temp009009"
        case "iPhone12,1":         return "iPhone 11"
        case "iPhone12,3":         return "iPhone 11 Pro"
        case "iPhone12,5":         return "iPhone 11 Pro Max"
        case "iPhone12,8":         return "iPhone SE (2nd generation)"
        case "iPhone13,1":         return "iPhone 12 mini"
        case "iPhone13,2":         return "iPhone 12"
        case "iPhone13,3":         return "iPhone 12 Pro"
        case "iPhone13,4":         return "iPhone 12 Pro Max"
        case "iPhone14,4":         return "iPhone 13 mini"
        case "iPhone14,5":         return "iPhone 13"
        case "iPhone14,2":         return "iPhone 13 Pro"
        case "iPhone14,3":         return "iPhone 13 Pro Max"
        case "iPhone14,6":         return "iPhone SE (3rd generation)"
        case "iPhone14,7":         return "iPhone 14"
        case "iPhone14,8":         return "iPhone 14 Plus"
        case "iPhone15,2":         return "iPhone 14 Pro"
        case "iPhone15,3":         return "iPhone 14 Pro Max"
            
        case "iPod1,1":            return "iPod touch"
        case "iPod2,1":            return "iPod touch (2nd generation)"
        case "iPod3,1":            return "iPod touch (3rd generation)"
        case "iPod4,1":            return "iPod touch (4th generation)"
        case "iPod5,1":            return "iPod touch (5th generation)"
        case "iPod7,1":            return "iPod touch (6th generation)"
        case "iPod9,1":            return "iPod touch (7th generation)"
            
        case "i386", "x86_64":     return "Simulator"
        default:                   return identifier
        }
    }
}
